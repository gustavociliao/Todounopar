export class Task {
_id?: string;
codigo?: number;
description?: string;
completed?: boolean;
}