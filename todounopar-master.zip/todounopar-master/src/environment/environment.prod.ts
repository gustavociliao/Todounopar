export class environment {
  production: boolean = true;
  apiUrl: string = 'https://api.unopartodo.com.br';
}
