export class environment {
  production: boolean = false;
 static apiUrl: string = 'http://localhost:3000';
}
